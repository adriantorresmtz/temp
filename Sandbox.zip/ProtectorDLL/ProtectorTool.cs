﻿using System;
using System.Runtime.InteropServices;

namespace ProtectorDLL
{
    [ComVisible(true)]
    [Guid("4EA3AB36-9DD1-42C5-B57A-D0F89DC4711B")]
    public class ProtectorTool
    {
        public string access(string data, string cryptId)
        {
            return data.Replace("*","");
        }

        public string protect(string data, string cryptId)
        {
            return $"**{data}**";
        }
    }
}
